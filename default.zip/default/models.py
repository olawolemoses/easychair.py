# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    type = models.CharField(max_length=100, default="admin", blank=False, null=False)
    location = models.CharField(max_length=100, blank=True, null=True)
    skype = models.CharField(max_length=100, blank=True, null=True)
    facebook = models.CharField(max_length=100, blank=True, null=True)
    twitter = models.CharField(max_length=100, blank=True, null=True)
    interests = models.TextField(blank=True, null=True)
    photoURL =  models.CharField(max_length=250, blank=False, null=False)
    REQUIRED_FIELDS = ['type', 'email', 'first_name', 'last_name']


from .managers import AdminUserManager
class AdminUser(User):
    objects = AdminUserManager()

    class Meta:
        proxy = True
        ordering = ('first_name', )

    def do_something(self):
        pass

from .managers import ReviewerUserManager
class ReviewerUser(User):
    objects = ReviewerUserManager()

    class Meta:
        proxy = True
        ordering = ('first_name', )

    def do_something(self):
        pass
