from django import forms

from django.core import validators

# def validate_password(value):
#     if value % 2 != 0:
#         raise ValidationError(
#             _('%(value)s is not an even number'),
#             params={'value': value},
#         )

class RegisterForm(forms.Form):

    fname = forms.CharField(label='Firstname', required=True, max_length=100,
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder':"Firstname",
                                    }
                                ))
    lname = forms.CharField(label='Lastname', required=True, max_length=100,
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder':"Lastname",
                                    }
                                ))
    email = forms.CharField(label='Email Address', required=True, max_length=100,
                            validators=[validators.validate_email],
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder':"Email Address",
                                    }
                                ))
    password = forms.CharField(label='Password', required=True, max_length=100,
                            widget=forms.PasswordInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder':"Password"
                                    }
                                ))
    confirm_password = forms.CharField(label='Confirm Password',required=True,  max_length=100,
                            widget=forms.PasswordInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder':"Confirm Password"
                                    }
                                ))
    def clean(self):

        cleaned_data = super(RegisterForm, self).clean()

        password = cleaned_data.get("password")

        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password:
            # Only do something if both fields are valid so far.
            if confirm_password != password:

                raise forms.ValidationError(
                    "Confirm Password is not the same as Password "
                )
